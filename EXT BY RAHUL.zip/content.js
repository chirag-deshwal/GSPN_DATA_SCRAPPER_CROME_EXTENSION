/**
 * GSPN Data Scraper - Content Script
 * Parses service ticket data from the Samsung GSPN multi-print page.
 * Each ticket block is a <table width="100%" height="980"> containing
 * a nested data table with CSS classes PboxV_T_bold / PboxV_B_bold for labels
 * and PboxV_T / PboxV_B / PboxV_TR / PboxV_BR for values.
 */

// Field mapping: label text -> clean key name
const FIELD_MAP = {
  'Customer Name': 'Customer Name',
  'Service Order No': 'Service Order No',
  'Customer No': 'Customer No',
  'Address': 'Address',
  'Model Name': 'Model Name',
  'E-Mail': 'E-Mail',
  'Engineer': 'Engineer',
  'Telephone(Home)': 'Telephone (Home)',
  'Customer Preferred Date': 'Customer Preferred Date',
  'Service Type': 'Service Type',
  'Telephone(Office)': 'Telephone (Office)',
  'Purchase Date': 'Purchase Date',
  'Appointment Date': 'Appointment Date',
  'Telephone(Mobile)': 'Telephone (Mobile)',
  'ASC Assigned': 'ASC Assigned',
  'Symptom 1': 'Symptom 1',
  'Symptom 2': 'Symptom 2',
  'Symptom 3': 'Symptom 3',
  '1st Service Comment': '1st Service Comment',
  'Remark': 'Remark'
};

// Ordered columns for the Excel export
const COLUMN_ORDER = [
  'Service Order No',
  'Customer Name',
  'Customer No',
  'Address',
  'Model Name',
  'E-Mail',
  'Engineer',
  'Telephone (Home)',
  'Telephone (Office)',
  'Telephone (Mobile)',
  'Customer Preferred Date',
  'Purchase Date',
  'Appointment Date',
  'Service Type',
  'ASC Assigned',
  'Symptom 1',
  'Symptom 2',
  'Symptom 3',
  '1st Service Comment',
  'Remark'
];

/**
 * Clean extracted text: trim whitespace, collapse multiple spaces,
 * remove &nbsp; remnants.
 */
function cleanText(text) {
  if (!text) return '';
  return text
    .replace(/\u00A0/g, ' ')   // Replace &nbsp;
    .replace(/\s+/g, ' ')       // Collapse whitespace
    .trim();
}

/**
 * Parse a single ticket table block and return a data object.
 */
function parseTicketBlock(tableEl) {
  const data = {};

  // Find all rows in the innermost data table (the one with PboxV_* classes)
  const rows = tableEl.querySelectorAll('tr');

  for (const row of rows) {
    const cells = row.querySelectorAll('td');

    for (let i = 0; i < cells.length; i++) {
      const cell = cells[i];
      const className = cell.className || '';

      // Check if this cell is a label cell (bold class)
      const isLabel = className.includes('PboxV_T_bold') ||
                      className.includes('PboxV_B_bold') ||
                      className.includes('Pboxv_B_bold');

      if (isLabel) {
        const labelText = cleanText(cell.textContent);

        // Find the mapped field name
        let fieldName = null;
        for (const [key, value] of Object.entries(FIELD_MAP)) {
          if (labelText.includes(key)) {
            fieldName = value;
            break;
          }
        }

        if (fieldName) {
          // The value is in the next cell(s)
          let valueCell = cells[i + 1];
          if (valueCell) {
            const valueClassName = valueCell.className || '';
            // Only grab value from non-label cells
            if (!valueClassName.includes('bold')) {
              // For address, the colspan=3 cell contains the full address
              // For 1st Service Comment and Remark, colspan=5
              const colSpan = parseInt(valueCell.getAttribute('colspan') || '1');
              data[fieldName] = cleanText(valueCell.textContent);
            }
          }
        }
      }
    }
  }

  return data;
}

/**
 * Scrape all ticket blocks from the page.
 */
function scrapeAllTickets() {
  const tickets = [];

  // Each ticket is wrapped in a <table width="100%" height="980">
  // Inside there's a nested table with the actual data (PboxV_* classes)
  const outerTables = document.querySelectorAll('table[width="100%"][height="980"]');

  for (const outerTable of outerTables) {
    // Find the data table inside (with PboxV_T_bold cells)
    const dataTables = outerTable.querySelectorAll('table[width="100%"][border="0"][cellspacing="0"][cellpadding="0"]');

    for (const dataTable of dataTables) {
      // Check if this table has PboxV_T_bold cells (it's a data table)
      const boldCells = dataTable.querySelectorAll('td.PboxV_T_bold');
      if (boldCells.length > 0) {
        const ticketData = parseTicketBlock(dataTable);
        // Only add if we got meaningful data
        if (ticketData['Service Order No'] || ticketData['Customer Name']) {
          tickets.push(ticketData);
        }
        break; // Only process the first data table per outer block
      }
    }
  }

  return { tickets, columns: COLUMN_ORDER };
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'scrapeData') {
    try {
      const result = scrapeAllTickets();
      sendResponse({
        success: true,
        data: result.tickets,
        columns: result.columns,
        count: result.tickets.length
      });
    } catch (error) {
      sendResponse({
        success: false,
        error: error.message
      });
    }
  }
  return true; // Keep message channel open for async response
});
