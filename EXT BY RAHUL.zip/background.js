/**
 * background.js — Service Worker for GSPN Data Scraper extension
 * Handles opening the Closer Helper settings page in a new tab.
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'openCloserSettings') {
    chrome.tabs.create({ url: chrome.runtime.getURL('closer_helper_settings.html') });
  }
});
