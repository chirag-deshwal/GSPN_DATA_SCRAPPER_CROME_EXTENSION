/**
 * Closer Helper Settings Page Logic
 * Loads product definitions from products_keys.json (master config).
 * Saves presets to chrome.storage.local under key "closerPresets".
 * Each preset: { id, product, workType, name, fields: { fieldId: value, ... }, fieldMap }
 */

let productConfig = {};   // loaded from products_keys.json
let presets = [];
let activePresetId = null;

/* ─── DOM refs ─── */
const $  = id => document.getElementById(id);
const tabsEl       = $('presetTabs');
const editorEl     = $('presetEditor');
const emptyEl      = $('emptyState');
const toastEl      = $('toast');
const toastTextEl  = $('toastText');

/* ─── Load product config from JSON ─── */
async function loadProductConfig() {
  try {
    const url = chrome.runtime.getURL('webpage_source/src/products_keys.json');
    const resp = await fetch(url);
    const data = await resp.json();
    productConfig = data.products || {};
    console.log('[CloserSettings] Loaded product config:', Object.keys(productConfig));
  } catch (e) {
    console.error('[CloserSettings] Failed to load products_keys.json:', e);
    productConfig = {};
  }
}

/* ─── Storage helpers ─── */
function loadPresets() {
  return new Promise(resolve => {
    chrome.storage.local.get('closerPresets', data => {
      presets = data.closerPresets || [];
      resolve();
    });
  });
}
function savePresets() {
  return new Promise(resolve => {
    chrome.storage.local.set({ closerPresets: presets }, resolve);
  });
}

/* ─── Toast ─── */
function showToast(msg, isError = false) {
  toastTextEl.textContent = msg;
  toastEl.classList.remove('hidden', 'error');
  if (isError) toastEl.classList.add('error');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => toastEl.classList.add('hidden'), 2500);
}

/* ─── Render tabs ─── */
function renderTabs() {
  tabsEl.innerHTML = '';
  presets.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'preset-tab' + (p.id === activePresetId ? ' active' : '');
    btn.textContent = p.name || 'Untitled';
    btn.addEventListener('click', () => selectPreset(p.id));
    tabsEl.appendChild(btn);
  });
  emptyEl.classList.toggle('hidden', presets.length > 0);
  editorEl.classList.toggle('hidden', !activePresetId);
}

/* ─── Populate product dropdown ─── */
function populateProductDropdown(selectedProduct) {
  const sel = $('presetProduct');
  if (!sel) return;
  sel.innerHTML = '<option value="">— Select Product —</option>';
  Object.keys(productConfig).forEach(key => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = `${key} — ${productConfig[key].label}`;
    if (key === selectedProduct) opt.selected = true;
    sel.appendChild(opt);
  });
}

/* ─── Populate work type dropdown based on selected product ─── */
function populateWorkTypeDropdown(productKey, selectedWorkType) {
  const sel = $('presetWorkType');
  if (!sel) return;
  sel.innerHTML = '<option value="">— Select Work Type —</option>';
  const product = productConfig[productKey];
  if (!product || !product.workTypes) return;
  Object.keys(product.workTypes).forEach(key => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = product.workTypes[key].label;
    if (key === selectedWorkType) opt.selected = true;
    sel.appendChild(opt);
  });
}

/* ─── Render editable fields based on product + workType ─── */
function renderFieldEditor(productKey, workTypeKey) {
  const container = $('dynamicFields');
  if (!container) return;
  container.innerHTML = '';

  const product = productConfig[productKey];
  if (!product || !product.workTypes || !product.workTypes[workTypeKey]) {
    container.innerHTML = '<p class="section-hint">Select a Product and Work Type above to see fields.</p>';
    return;
  }

  const fields = product.workTypes[workTypeKey].fields;
  const preset = presets.find(p => p.id === activePresetId);
  const savedFields = preset?.fields || {};

  // Helper: get saved value or default
  function val(fieldId) {
    if (savedFields[fieldId] !== undefined) return savedFields[fieldId];
    return fields[fieldId]?.value || '';
  }
  function hint(fieldId) {
    return fields[fieldId]?.valueLabel || '';
  }

  // Build GSPN-style table layout
  let html = '<table class="gspn-form-table">';

  // ── Text areas (full-width rows) ──
  // Status Comment
  if (fields['STATUS_COMMENT']) {
    html += `<tr>
      <td class="gspn-label">▪ Status Comment</td>
      <td class="gspn-input" colspan="3">
        <input type="text" data-field-id="STATUS_COMMENT" value="${escapeHtml(val('STATUS_COMMENT'))}" placeholder="Status Comment..." />
      </td>
    </tr>`;
  }

  // Remark
  if (fields['REMARK']) {
    html += `<tr>
      <td class="gspn-label">▪ Remark</td>
      <td class="gspn-input" colspan="3">
        <input type="text" data-field-id="REMARK" value="${escapeHtml(val('REMARK'))}" placeholder="Remark..." />
      </td>
    </tr>`;
  }

  // Defect Detail DESC
  if (fields['DEFECTDESC_L']) {
    html += `<tr>
      <td class="gspn-label">▪ Defect Detail DESC</td>
      <td class="gspn-input" colspan="3">
        <textarea data-field-id="DEFECTDESC_L" rows="2" placeholder="Defect Detail...">${escapeHtml(val('DEFECTDESC_L'))}</textarea>
      </td>
    </tr>`;
  }

  // Repair Detail DESC
  if (fields['REPAIRDESC_L']) {
    html += `<tr>
      <td class="gspn-label">▪ Repair Detail DESC</td>
      <td class="gspn-input" colspan="3">
        <textarea data-field-id="REPAIRDESC_L" rows="2" placeholder="Repair Detail...">${escapeHtml(val('REPAIRDESC_L'))}</textarea>
      </td>
    </tr>`;
  }

  // ── Paired dropdown rows ──

  // Row: Defect Type | Defect Block
  if (fields['LAB_TYPE'] || fields['DEF_BLK']) {
    html += `<tr>
      <td class="gspn-label">▪ Defect Type</td>
      <td class="gspn-input">
        <input type="text" data-field-id="LAB_TYPE" value="${escapeHtml(val('LAB_TYPE'))}" placeholder="${hint('LAB_TYPE') || 'e.g. FL'}" />
      </td>
      <td class="gspn-label">▪ Defect Block</td>
      <td class="gspn-input">
        <input type="text" data-field-id="DEF_BLK" value="${escapeHtml(val('DEF_BLK'))}" placeholder="${hint('DEF_BLK') || 'e.g. 9999'}" />
      </td>
    </tr>`;
  }

  // Row: Condition Code | Symptom Code (Q-Code + Code)
  html += `<tr>
    <td class="gspn-label">▪ Condition Code</td>
    <td class="gspn-input">
      <input type="text" data-field-id="IRIS_CONDI" value="${escapeHtml(val('IRIS_CONDI'))}" placeholder="${hint('IRIS_CONDI') || 'e.g. 4'}" />
    </td>
    <td class="gspn-label">Symptom Code</td>
    <td class="gspn-input">
      <div class="gspn-dual-input">
        <input type="text" data-field-id="IRIS_SYMPT_QCODE" value="${escapeHtml(val('IRIS_SYMPT_QCODE'))}" placeholder="${hint('IRIS_SYMPT_QCODE') || 'Q-Code'}" title="Symptom Q-Code (parent)" />
        <input type="text" data-field-id="IRIS_SYMPT" value="${escapeHtml(val('IRIS_SYMPT'))}" placeholder="${hint('IRIS_SYMPT') || 'Code'}" title="Symptom Code (child)" />
      </div>
    </td>
  </tr>`;

  // Row: Defect Code | Repair Code (Q-Code + Code)
  html += `<tr>
    <td class="gspn-label">▪ Defect Code</td>
    <td class="gspn-input">
      <input type="text" data-field-id="IRIS_DEFECT" value="${escapeHtml(val('IRIS_DEFECT'))}" placeholder="${hint('IRIS_DEFECT') || 'e.g. R'}" />
    </td>
    <td class="gspn-label">Repair Code</td>
    <td class="gspn-input">
      <div class="gspn-dual-input">
        <input type="text" data-field-id="IRIS_REPAIR_QCODE" value="${escapeHtml(val('IRIS_REPAIR_QCODE'))}" placeholder="${hint('IRIS_REPAIR_QCODE') || 'Q-Code'}" title="Repair Q-Code (parent)" />
        <input type="text" data-field-id="IRIS_REPAIR" value="${escapeHtml(val('IRIS_REPAIR'))}" placeholder="${hint('IRIS_REPAIR') || 'Code'}" title="Repair Code (child)" />
      </div>
    </td>
  </tr>`;

  // Row: Reason Code (full width)
  if (fields['REASON']) {
    html += `<tr>
      <td class="gspn-label">▪ Reason Code</td>
      <td class="gspn-input" colspan="3">
        <input type="text" data-field-id="REASON" value="${escapeHtml(val('REASON'))}" placeholder="${hint('REASON') || 'e.g. HLZ23'}" />
      </td>
    </tr>`;
  }

  html += '</table>';
  container.innerHTML = html;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* ─── Select preset ─── */
function selectPreset(id) {
  activePresetId = id;
  const p = presets.find(x => x.id === id);
  if (!p) return;

  $('presetName').value = p.name || '';
  populateProductDropdown(p.product);
  populateWorkTypeDropdown(p.product, p.workType);
  renderFieldEditor(p.product, p.workType);
  renderTabs();
}

/* ─── Add preset ─── */
$('btnAddPreset').addEventListener('click', () => {
  const newPreset = {
    id: Date.now().toString(),
    name: '',
    product: '',
    workType: '',
    fields: {},
    fieldMap: {}
  };
  presets.push(newPreset);
  selectPreset(newPreset.id);
  $('presetName').focus();
  savePresets();
});

/* ─── Save preset ─── */
$('btnSave').addEventListener('click', () => {
  if (!activePresetId) return;
  const idx = presets.findIndex(x => x.id === activePresetId);
  if (idx < 0) return;

  const name = $('presetName').value.trim();
  if (!name) {
    showToast('Please enter a preset name!', true);
    $('presetName').focus();
    return;
  }

  const product = $('presetProduct').value;
  const workType = $('presetWorkType').value;

  // Collect all field values from the dynamic editor
  const fields = {};
  document.querySelectorAll('[data-field-id]').forEach(el => {
    const fieldId = el.dataset.fieldId;
    const val = (el.value || '').trim();
    if (val) fields[fieldId] = val;
  });

  // Also populate hidden mirror fields if their visible counterpart has a value
  if (fields['REPAIRDESC_L'])  fields['REPAIR_DESC'] = fields['REPAIRDESC_L'];
  if (fields['DEFECTDESC_L'])  fields['DEFECT_DESC'] = fields['DEFECTDESC_L'];

  // Build the old-format preset data for backward compatibility with closerContent.js
  const preset = {
    id: activePresetId,
    name,
    product,
    workType,
    fields,
    // Legacy flat fields for closerContent.js compatibility
    repairDetailDesc: fields['REPAIRDESC_L'] || '',
    defectDetailDesc: fields['DEFECTDESC_L'] || '',
    statusComment:    fields['STATUS_COMMENT'] || '',
    remark:           fields['REMARK'] || '',
    conditionCode:    fields['IRIS_CONDI'] || '',
    defectType:       fields['LAB_TYPE'] || '',
    defectBlock:      fields['DEF_BLK'] || '',
    reasonCode:       fields['REASON'] || '',
    defectCode:       fields['IRIS_DEFECT'] || '',
    symptomQCode:     fields['IRIS_SYMPT_QCODE'] || '',
    symptomCode:      fields['IRIS_SYMPT'] || '',
    repairQCode:      fields['IRIS_REPAIR_QCODE'] || '',
    repairCode:       fields['IRIS_REPAIR'] || '',
    fieldMap: {
      repairDetail:  'REPAIRDESC_L',
      defectDetail:  'DEFECTDESC_L',
      statusComment: 'STATUS_COMMENT',
      remark:        'REMARK',
      symptom:       'IRIS_SYMPT',
      defectBlock:   'DEF_BLK',
      repairCode:    'IRIS_REPAIR',
      condition:     'IRIS_CONDI',
      defectType:    'LAB_TYPE',
      defectCode:    'IRIS_DEFECT'
    }
  };

  presets[idx] = preset;

  savePresets().then(() => {
    renderTabs();
    showToast(`"${name}" saved ✓`);
  });
});

/* ─── Delete preset ─── */
$('btnDelete').addEventListener('click', () => {
  if (!activePresetId) return;
  const p = presets.find(x => x.id === activePresetId);
  if (!confirm(`Delete preset "${p?.name || 'Untitled'}"?`)) return;
  presets = presets.filter(x => x.id !== activePresetId);
  activePresetId = presets.length ? presets[0].id : null;
  savePresets().then(() => {
    if (activePresetId) selectPreset(activePresetId);
    else {
      editorEl.classList.add('hidden');
      renderTabs();
    }
    showToast('Preset deleted');
  });
});

/* ─── Product / Work Type change handlers ─── */
document.addEventListener('change', (e) => {
  if (e.target.id === 'presetProduct') {
    const productKey = e.target.value;
    populateWorkTypeDropdown(productKey, '');
    renderFieldEditor(productKey, '');
  }
  if (e.target.id === 'presetWorkType') {
    const productKey = $('presetProduct').value;
    const workTypeKey = e.target.value;
    renderFieldEditor(productKey, workTypeKey);

    // Auto-fill default values from products_keys.json if fields are empty
    const product = productConfig[productKey];
    if (product && product.workTypes && product.workTypes[workTypeKey]) {
      const fields = product.workTypes[workTypeKey].fields;
      Object.entries(fields).forEach(([fieldId, def]) => {
        const el = $(`field_${fieldId}`);
        if (el && !el.value && def.value) {
          el.value = def.value;
        }
      });
    }
  }
});

/* ─── Init ─── */
(async () => {
  await loadProductConfig();
  await loadPresets();
  if (presets.length) {
    activePresetId = presets[0].id;
    selectPreset(activePresetId);
  }
  renderTabs();
})();
