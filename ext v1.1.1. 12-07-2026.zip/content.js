/**
 * GSPN Data Scraper - Content Script
 * Parses service ticket data from the Samsung GSPN multi-print page.
 * Each ticket block is a <table width="100%" height="980"> containing
 * a nested data table with CSS classes PboxV_T_bold / PboxV_B_bold for labels
 * and PboxV_T / PboxV_B / PboxV_TR / PboxV_BR for values.
 */

// Field mapping: label text -> clean key name
const FIELD_MAP = {
  'Customer Name': 'Customer Name',
  'Service Order No': 'Service Order No',
  'Customer No': 'Customer No',
  'Address': 'Address',
  'Model Name': 'Model Name',
  'Engineer': 'Engineer',
  'Telephone(Home)': 'Telephone (Home)',
  'Customer Preferred Date': 'Customer Preferred Date',
  'Service Type': 'Service Type',
  'Telephone(Office)': 'Telephone (Office)',
  'Purchase Date': 'Purchase Date',
  'Appointment Date': 'Appointment Date',
  'Telephone(Mobile)': 'Telephone (Mobile)',
  'ASC Assigned': 'ASC Assigned',
  'Symptom 1': 'Symptom 1',
  'Symptom 2': 'Symptom 2',
  'Symptom 3': 'Symptom 3',
  '1st Service Comment': '1st Service Comment',
  'Remark': 'Remark'
};

// Ordered columns for the Excel export
const COLUMN_ORDER = [
  'Service Order No',
  'Customer Name',
  'Customer No',
  'Address',
  'Model Name',
  'Engineer',
  'Telephone (Home)',
  'Telephone (Office)',
  'Telephone (Mobile)',
  'Customer Preferred Date',
  'Purchase Date',
  'Appointment Date',
  'Service Type',
  'ASC Assigned',
  'Symptom 1',
  'Symptom 2',
  'Symptom 3',
  '1st Service Comment',
  'Remark'
];

const LOG_SOURCE = 'content';

function formatLogValue(value) {
  if (typeof value === 'string') return value;
  if (value instanceof Error) return value.message;
  try {
    return JSON.stringify(value);
  } catch (error) {
    return String(value);
  }
}

function publishExtensionLog(level, args) {
  const message = args.map(formatLogValue).join(' ');
  if (!message) return;
  chrome.runtime.sendMessage({
    action: 'extensionLog',
    entry: {
      source: LOG_SOURCE,
      level,
      message,
      timestamp: new Date().toISOString()
    }
  }).catch(() => {});
}

['log', 'info', 'warn', 'error', 'debug'].forEach((method) => {
  const original = console[method];
  console[method] = (...args) => {
    publishExtensionLog(method, args);
    if (original) {
      original.apply(console, args);
    }
  };
});

/**
 * Clean extracted text: trim whitespace, collapse multiple spaces,
 * remove &nbsp; remnants.
 */
function cleanText(text) {
  if (!text) return '';
  return text
    .replace(/\u00A0/g, ' ')   // Replace &nbsp;
    .replace(/\s+/g, ' ')       // Collapse whitespace
    .trim();
}

/**
 * Parse a single ticket table block and return a data object.
 */
function parseTicketBlock(tableEl) {
  const data = {};

  // Find all rows in the innermost data table (the one with PboxV_* classes)
  const rows = tableEl.querySelectorAll('tr');

  for (const row of rows) {
    const cells = row.querySelectorAll('td');

    for (let i = 0; i < cells.length; i++) {
      const cell = cells[i];
      const className = cell.className || '';

      // Check if this cell is a label cell (bold class)
      const isLabel = className.includes('PboxV_T_bold') ||
                      className.includes('PboxV_B_bold') ||
                      className.includes('Pboxv_B_bold');

      if (isLabel) {
        const labelText = cleanText(cell.textContent);

        // Find the mapped field name
        let fieldName = null;
        for (const [key, value] of Object.entries(FIELD_MAP)) {
          if (labelText.includes(key)) {
            fieldName = value;
            break;
          }
        }

        if (fieldName) {
          // The value is in the next cell(s)
          let valueCell = cells[i + 1];
          if (valueCell) {
            const valueClassName = valueCell.className || '';
            // Only grab value from non-label cells
            if (!valueClassName.includes('bold')) {
              // For address, the colspan=3 cell contains the full address
              // For 1st Service Comment and Remark, colspan=5
              const colSpan = parseInt(valueCell.getAttribute('colspan') || '1');
              data[fieldName] = cleanText(valueCell.textContent);
            }
          }
        }
      }
    }
  }

  return data;
}
const VIEW_MODE_LABEL_MAP = [
  ['Service Order No.', 'Service Order No'],
  ['Service Order No', 'Service Order No'],
  ['ASC Job No', 'ASC Job No'],
  ['Customer Preferred Date', 'Customer Preferred Date'],
  ['Customer', 'Customer Name'],
  ['Customer No', 'Customer No'],
  ['Phone No', 'Telephone'],
  ['ASC Assigned', 'ASC Assigned'],
  ['Call Received', 'Call Received'],
  ['ASC 1st App', 'ASC 1st App'],
  ['1st Visit', '1st Visit'],
  ['Repair Completed', 'Repair Completed'],
  ['Status Comment', 'Status Comment'],
  ['Service Type', 'Service Type'],
  ['Engineer', 'Engineer'],
  ['Remark', 'Remark'],
  ['Purchase Date', 'Purchase Date'],
  ['Model', 'Model Name'],
  ['Service Branch', 'Service Branch'],
  ['Job Information(Date)', 'Job Information(Date)'],
  ['Customer Symptom', 'Customer Symptom']
];

function mapViewLabelToField(labelText) {
  const normalized = labelText.replace(/\s+/g, ' ').trim();
  for (const [match, field] of VIEW_MODE_LABEL_MAP) {
    if (normalized.includes(match)) {
      return field;
    }
  }
  return null;
}

function parseViewModePhoneValues(rawValue) {
  const result = {};
  const homeMatch = rawValue.match(/\[Home\]\s*([0-9+\-\s]+)/i);
  const officeMatch = rawValue.match(/\[Office\]\s*([0-9+\-\s]+)/i);
  const mobileMatch = rawValue.match(/\[Mobile\]\s*([0-9+\-\s]+)/i);

  if (homeMatch) {
    result['Telephone (Home)'] = cleanText(homeMatch[1]);
  }
  if (officeMatch) {
    result['Telephone (Office)'] = cleanText(officeMatch[1]);
  }
  if (mobileMatch) {
    result['Telephone (Mobile)'] = cleanText(mobileMatch[1]);
  }

  if (!homeMatch && !officeMatch && !mobileMatch) {
    result['Telephone'] = cleanText(rawValue);
  }

  return result;
}

function parseViewModeTicket() {
  const ticket = {};

  const inputObjectId = document.querySelector('input#OBJECT_ID');
  const spanObjectId = document.querySelector('span#OBJECT_ID');
  const rawObjectId = inputObjectId?.value || spanObjectId?.textContent;

  if (rawObjectId) {
    ticket['Service Order No'] = cleanText(rawObjectId);
  }

  const rows = document.querySelectorAll('table.sertb_brdr tr');
  for (const row of rows) {
    const cells = Array.from(row.querySelectorAll('td'));
    for (let i = 0; i < cells.length; i += 1) {
      const cell = cells[i];
      if (!cell.className || !cell.className.includes('ser_ti')) continue;

      const labelText = cleanText(cell.textContent);
      if (!labelText) continue;

      const valueCell = cells[i + 1];
      if (!valueCell) continue;

      const rawValue = cleanText(valueCell.textContent);
      if (!rawValue) continue;

      if (labelText.includes('Phone No')) {
        Object.assign(ticket, parseViewModePhoneValues(rawValue));
        continue;
      }

      if (labelText === 'Customer') {
        const phoneMatch = rawValue.match(/([0-9]{5,})\s*$/);
        if (phoneMatch) {
          ticket['Customer No'] = phoneMatch[1];
        }
        const customerName = rawValue.replace(/([0-9]{5,})\s*$/, '').trim();
        ticket['Customer Name'] = cleanText(customerName);
        continue;
      }

      const fieldName = mapViewLabelToField(labelText);
      if (fieldName) {
        if (!ticket[fieldName]) {
          ticket[fieldName] = rawValue;
        }
      } else {
        ticket[labelText] = rawValue;
      }
    }
  }

  if (!ticket['Service Order No'] && !ticket['Customer Name']) {
    return null;
  }

  return ticket;
}

function getColumnsForTicket(ticket) {
  const columns = [...COLUMN_ORDER];
  for (const field of Object.keys(ticket)) {
    if (!columns.includes(field)) {
      columns.push(field);
    }
  }
  return columns;
}
/**
 * Scrape all ticket blocks from the page.
 */
function scrapeAllTickets() {
  const tickets = [];

  // Each ticket is wrapped in a <table width="100%" height="980">
  // Inside there's a nested table with the actual data (PboxV_* classes)
  const outerTables = document.querySelectorAll('table[width="100%"][height="980"]');

  for (const outerTable of outerTables) {
    // Find the data table inside (with PboxV_T_bold cells)
    const dataTables = outerTable.querySelectorAll('table[width="100%"][border="0"][cellspacing="0"][cellpadding="0"]');

    for (const dataTable of dataTables) {
      // Check if this table has PboxV_T_bold cells (it's a data table)
      const boldCells = dataTable.querySelectorAll('td.PboxV_T_bold');
      if (boldCells.length > 0) {
        const ticketData = parseTicketBlock(dataTable);
        // Only add if we got meaningful data
        if (ticketData['Service Order No'] || ticketData['Customer Name']) {
          tickets.push(ticketData);
        }
        break; // Only process the first data table per outer block
      }
    }
  }

  return { tickets, columns: COLUMN_ORDER };
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'scrapeViewMode') {
    try {
      const ticket = parseViewModeTicket();
      if (!ticket) {
        sendResponse({ success: false, error: 'No view-mode ticket found on this page.' });
      } else {
        sendResponse({
          success: true,
          data: [ticket],
          columns: getColumnsForTicket(ticket),
          count: 1
        });
      }
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
    return true;
  }

  if (request.action === 'scrapeData') {
    try {
      const result = scrapeAllTickets();
      sendResponse({
        success: true,
        data: result.tickets,
        columns: result.columns,
        count: result.tickets.length
      });
    } catch (error) {
      sendResponse({
        success: false,
        error: error.message
      });
    }
  }
  return true; // Keep message channel open for async response
});
