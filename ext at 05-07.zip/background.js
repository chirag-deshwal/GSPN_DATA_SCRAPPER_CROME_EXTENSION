/**
 * background.js — Service Worker for GSPN Data Scraper extension
 * Handles opening the Closer Helper settings page in a new tab
 * and stores runtime debug logs from the popup and content scripts.
 */
const MAX_LOG_ENTRIES = 250;

function normalizeLogEntry(entry) {
  return {
    id: entry?.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    source: entry?.source || 'unknown',
    level: entry?.level || 'log',
    message: entry?.message || '',
    timestamp: entry?.timestamp || new Date().toISOString(),
    url: entry?.url || ''
  };
}

function storeLog(entry) {
  const normalized = normalizeLogEntry(entry);
  chrome.storage.local.get({ extensionLogs: [] }, (result) => {
    const logs = Array.isArray(result.extensionLogs) ? result.extensionLogs : [];
    logs.push(normalized);
    if (logs.length > MAX_LOG_ENTRIES) {
      logs.splice(0, logs.length - MAX_LOG_ENTRIES);
    }
    chrome.storage.local.set({ extensionLogs: logs });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'openCloserSettings') {
    chrome.tabs.create({ url: chrome.runtime.getURL('closer_helper_settings.html') });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'extensionLog') {
    storeLog({
      ...msg.entry,
      url: sender?.url || ''
    });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'getExtensionLogs') {
    chrome.storage.local.get({ extensionLogs: [] }, (result) => {
      const logs = Array.isArray(result.extensionLogs) ? result.extensionLogs : [];
      sendResponse({ logs });
    });
    return true;
  }

  if (msg.action === 'clearExtensionLogs') {
    chrome.storage.local.set({ extensionLogs: [] }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});
