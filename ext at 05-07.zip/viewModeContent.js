﻿/**
 * GSPN Data Scraper - View Mode Content Script
 * Handles dedicated scraping for the service order detail view mode.
 */

function cleanText(text) {
  if (!text) return '';
  return text
    .replace(/\u00A0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const VIEW_MODE_LABEL_MAP = [
  ['Service Order No.', 'Service Order No'],
  ['Service Order No', 'Service Order No'],
  ['ASC Job No', 'ASC Job No'],
  ['Customer Preferred Date', 'Customer Preferred Date'],
  ['Customer', 'Customer Name'],
  ['Customer No', 'Customer No'],
  ['Phone No', 'Telephone'],
  ['ASC Assigned', 'ASC Assigned'],
  ['Call Received', 'Call Received'],
  ['ASC 1st App', 'ASC 1st App'],
  ['1st Visit', '1st Visit'],
  ['Repair Completed', 'Repair Completed'],
  ['Status Comment', 'Status Comment'],
  ['Service Type', 'Service Type'],
  ['Engineer', 'Engineer'],
  ['Remark', 'Remark'],
  ['Purchase Date', 'Purchase Date'],
  ['Model', 'Model Name'],
  ['Service Branch', 'Service Branch'],
  ['Job Information(Date)', 'Job Information(Date)'],
  ['Customer Symptom', 'Customer Symptom']
];

function mapViewLabelToField(labelText) {
  const normalized = labelText.replace(/\s+/g, ' ').trim();
  for (const [match, field] of VIEW_MODE_LABEL_MAP) {
    if (normalized.includes(match)) {
      return field;
    }
  }
  return null;
}

function parseViewModePhoneValues(rawValue) {
  const result = {};
  const homeMatch = rawValue.match(/\[Home\]\s*([0-9+\-\s]+)/i);
  const officeMatch = rawValue.match(/\[Office\]\s*([0-9+\-\s]+)/i);
  const mobileMatch = rawValue.match(/\[Mobile\]\s*([0-9+\-\s]+)/i);

  if (homeMatch) result['Telephone (Home)'] = cleanText(homeMatch[1]);
  if (officeMatch) result['Telephone (Office)'] = cleanText(officeMatch[1]);
  if (mobileMatch) result['Telephone (Mobile)'] = cleanText(mobileMatch[1]);
  if (!homeMatch && !officeMatch && !mobileMatch) result['Telephone'] = cleanText(rawValue);

  return result;
}

function parseViewModeTicketInDocument(doc) {
  const ticket = {};
  const inputObjectId = doc.querySelector('input#OBJECT_ID');
  const spanObjectId = doc.querySelector('span#OBJECT_ID');
  const rawObjectId = inputObjectId?.value || spanObjectId?.textContent;

  if (rawObjectId) {
    ticket['Service Order No'] = cleanText(rawObjectId);
  }

  const rows = doc.querySelectorAll('table.sertb_brdr tr');
  for (const row of rows) {
    const cells = Array.from(row.querySelectorAll('td'));
    for (let i = 0; i < cells.length; i += 1) {
      const cell = cells[i];
      if (!cell.className || !cell.className.includes('ser_ti')) continue;

      const labelText = cleanText(cell.textContent);
      if (!labelText) continue;

      const valueCell = cells[i + 1];
      if (!valueCell) continue;

      const rawValue = cleanText(valueCell.textContent);
      if (!rawValue) continue;

      if (labelText.includes('Phone No')) {
        Object.assign(ticket, parseViewModePhoneValues(rawValue));
        continue;
      }

      if (labelText === 'Customer') {
        const phoneMatch = rawValue.match(/([0-9]{5,})\s*$/);
        if (phoneMatch) ticket['Customer No'] = phoneMatch[1];
        ticket['Customer Name'] = cleanText(rawValue.replace(/([0-9]{5,})\s*$/, '').trim());
        continue;
      }

      const fieldName = mapViewLabelToField(labelText);
      if (fieldName) {
        ticket[fieldName] = ticket[fieldName] || rawValue;
      } else {
        ticket[labelText] = rawValue;
      }
    }
  }

  if (!ticket['Service Order No'] && !ticket['Customer Name']) {
    return null;
  }

  return ticket;
}

function findViewModeTicket(doc) {
  const ticket = parseViewModeTicketInDocument(doc);
  if (ticket) return ticket;

  const iframes = Array.from(doc.querySelectorAll('iframe'));
  for (const frame of iframes) {
    try {
      const frameDoc = frame.contentDocument;
      if (!frameDoc) continue;
      const nestedTicket = findViewModeTicket(frameDoc);
      if (nestedTicket) return nestedTicket;
    } catch (error) {
      // Ignore cross-origin frames or unreadable content
    }
  }

  return null;
}

function parseServiceOrderListLiteTicketInDocument(doc) {
  const ticket = {};
  const objectIdInput = doc.querySelector('input#OBJECT_ID');
  if (objectIdInput && objectIdInput.value) {
    ticket['Service Order No'] = cleanText(objectIdInput.value);
  }

  const tableRows = doc.querySelectorAll('table.sertb_brdr tr');
  for (const row of tableRows) {
    const cells = Array.from(row.querySelectorAll('td.ser_ti, td.ser_td'));
    for (let i = 0; i < cells.length; i += 2) { // Process in pairs of label and value
      const labelCell = cells[i];
      const valueCell = cells[i + 1];

      if (labelCell && valueCell) {
        const labelText = cleanText(labelCell.textContent);
        const rawValue = cleanText(valueCell.textContent);

        if (!labelText) continue;

        if (labelText.includes('Service Order No.')) { // Prioritize input#OBJECT_ID if already set
          ticket['Service Order No'] = ticket['Service Order No'] || rawValue;
          continue;
        }

        if (labelText.includes('Customer')) {
          const customerMatch = rawValue.match(/(.+?),\s*(.+?)(?:\s*([0-9]+))?$/);
          if (customerMatch) {
            ticket['Customer Name'] = cleanText(customerMatch[1] + ', ' + customerMatch[2]);
            if (customerMatch[3]) ticket['Customer No'] = customerMatch[3];
          } else {
            ticket['Customer Name'] = rawValue;
          }
          continue;
        }

        if (labelText.includes('Phone No')) {
          Object.assign(ticket, parseViewModePhoneValues(rawValue));
          continue;
        }
        
        if (labelText.includes('Model')) {
          const modelMatch = rawValue.match(/^(\S+)/); // Extract first word as Model Name
          if (modelMatch) {
            ticket['Model Name'] = modelMatch[1];
          }
          continue;
        }

        const fieldName = mapViewLabelToField(labelText);
        if (fieldName) {
          ticket[fieldName] = ticket[fieldName] || rawValue;
        } else {
          // Add raw label if not mapped to capture all fields
          ticket[labelText] = rawValue;
        }
      }
    }
  }

  // Fallback for fields not captured by table parsing but available as _l variables
  if (typeof _l !== 'undefined') {
    ticket['Service Order No'] = ticket['Service Order No'] || (_l.ObjectId ? cleanText(_l.ObjectId.toString()) : '');
    ticket['Model Name'] = ticket['Model Name'] || (_l.MODEL ? cleanText(_l.MODEL.toString()) : '');
    ticket['Engineer'] = ticket['Engineer'] || (_l.ENGINEERNAME ? cleanText(_l.ENGINEERNAME.toString()) : '');
    ticket['Remark'] = ticket['Remark'] || (_l.REMARK ? cleanText(_l.REMARK.toString()) : '');
    ticket['Purchase Date'] = ticket['Purchase Date'] || (_l.PURCHASE_DATE ? cleanText(_l.PURCHASE_DATE.toString()) : '');
    ticket['ASC Assigned'] = ticket['ASC Assigned'] || (_l.ENG_ASSIGN_DATE ? cleanText(_l.ENG_ASSIGN_DATE.toString()) : '');
    ticket['Customer Symptom'] = ticket['Customer Symptom'] || (_l.DEFECT_DESC ? cleanText(_l.DEFECT_DESC.toString()) : '');
    ticket['1st Visit'] = ticket['1st Visit'] || (_l.FIRST_APP_DATE ? cleanText(_l.FIRST_APP_DATE.toString()) : '');
    ticket['Repair Completed'] = ticket['Repair Completed'] || (_l.REPAIR_COMP_DATE ? cleanText(_l.REPAIR_COMP_DATE.toString()) : '');
    ticket['Call Received'] = ticket['Call Received'] || (_l.CREATE_TIME ? cleanText(_l.CREATE_TIME.toString()) : '');
    ticket['Service Type'] = ticket['Service Type'] || (_l.SERVICE_TYPE ? cleanText(_l.SERVICE_TYPE.toString()) : '');
    ticket['Status Comment'] = ticket['Status Comment'] || (_l.DEFECT_DESC ? cleanText(_l.DEFECT_DESC.toString()) : ''); // Often same as Defect Desc

    // Specific mapping for Job Information(Date)
    ticket['Job Information(Date)'] = ticket['Job Information(Date)'] ||
      (ticket['Call Received'] || ticket['ASC Assigned'] || ticket['ASC 1st App'] || '');
  }

  if (!ticket['Service Order No'] && !ticket['Customer Name'] && !ticket['Model Name']) {
    return null;
  }

  return ticket;
}


async function scrapeFromIframe(iframeId, parseFunction) {
  try {
    const iframe = document.getElementById(iframeId);
    if (!iframe || !iframe.contentDocument) {
      console.warn(`Iframe with ID '${iframeId}' not found or inaccessible.`);
      return null;
    }
    return parseFunction(iframe.contentDocument);
  } catch (error) {
    console.error(`Error scraping iframe '${iframeId}':`, error);
    return null;
  }
}

async function parseViewModeTicket() {
  const currentUrl = window.location.href;

  // Match Service Order Management Light page â€” real GSPN URL or local saved HTML
  const isManagementLite = currentUrl.includes('ServiceOrderDetailLiteCmd')
    || currentUrl.includes('ServiceOrderListLite')
    || currentUrl.includes('so_view_information_by_mangement_lite')
    || currentUrl.includes('manegement_lite');

  if (isManagementLite) {
    // Try top-level document first
    const ticket = findViewModeTicket(document);
    if (ticket) return ticket;
    // Then fall back to rightContents iframe
    const iframeTicket = await scrapeFromIframe('rightContents', parseServiceOrderListLiteTicketInDocument);
    if (iframeTicket) return iframeTicket;
    // Try scanning all iframes for management lite content
    const iframes = Array.from(document.querySelectorAll('iframe'));
    for (const frame of iframes) {
      try {
        const frameDoc = frame.contentDocument;
        if (!frameDoc) continue;
        const t = parseServiceOrderListLiteTicketInDocument(frameDoc);
        if (t) return t;
        // Also try findViewModeTicket inside iframe
        const t2 = findViewModeTicket(frameDoc);
        if (t2) return t2;
      } catch (e) { /* cross-origin */ }
    }
    return null;
  } else if (currentUrl.includes('call_info_viewing_mode.html')) {
    // This is the call info viewing mode page
    return findViewModeTicket(document);
  }
  // Default to original behavior for other pages (works for real GSPN call info pages too)
  return findViewModeTicket(document);
}

function getColumnsForTicket(ticket) {
  const baseColumns = [
    'Service Order No',
    'Customer Name',
    'Customer No',
    'Address',
    'Model Name',
    'Engineer',
    'Telephone (Home)',
    'Telephone (Office)',
    'Telephone (Mobile)',
    'Customer Preferred Date',
    'Purchase Date',
    'Appointment Date',
    'Service Type',
    'ASC Assigned',
    'Symptom 1',
    'Symptom 2',
    'Symptom 3',
    '1st Service Comment',
    'Remark'
  ];
  const columns = [...baseColumns];
  for (const field of Object.keys(ticket)) {
    if (!columns.includes(field)) columns.push(field);
  }
  return columns;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'scrapeViewMode') {
    parseViewModeTicket()
      .then((ticket) => {
        if (!ticket) {
          sendResponse({ success: false, error: 'No view-mode ticket found on this page. Make sure the Service Order detail is open and visible.' });
        } else {
          sendResponse({
            success: true,
            data: [ticket],
            columns: getColumnsForTicket(ticket),
            count: 1
          });
        }
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // Keep the message channel open for async response
  }
});

// â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// FLOATING ACTION BUTTON â€” "Add 1-1-1 Report"
// Uses Shadow DOM so page CSS (transforms, overflow, z-index stacking contexts)
// cannot hide or clip the FAB.
// â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

const FAB_HOST_ID = 'gspn-fab-host-111'; // ID on the real DOM host element
let   _fabShadow  = null;                // reference to the shadow root

/** Inline CSS for the shadow DOM â€” use simple class names, no conflicts */
const FAB_SHADOW_CSS = `
  :host {
    all: initial;
    display: block !important;
    position: fixed !important;
    bottom: 0 !important;
    right: 0 !important;
    width: 0 !important;
    height: 0 !important;
    overflow: visible !important;
    z-index: 2147483647 !important;
    pointer-events: none !important;
  }

  /* â”€â”€ FAB button â”€â”€ */
  .fab-btn {
    all: unset;
    position: absolute;
    bottom: 20px;
    right: 20px;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 0 20px 0 16px;
    height: 52px;
    background: linear-gradient(135deg, #1a56db 0%, #3b82f6 100%);
    color: #ffffff;
    font-family: 'Segoe UI', 'Inter', Arial, sans-serif;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.1px;
    border-radius: 26px;
    box-shadow: 0 6px 24px rgba(26,86,219,0.45), 0 2px 8px rgba(0,0,0,0.22);
    cursor: pointer;
    user-select: none;
    white-space: nowrap;
    pointer-events: all;
    transition: transform 0.18s cubic-bezier(.22,1,.36,1),
                box-shadow 0.18s ease,
                filter 0.18s ease,
                background 0.45s ease;
    animation: fabIn 0.42s cubic-bezier(.22,1,.36,1) both;
  }
  @keyframes fabIn {
    from { opacity: 0; transform: translateY(30px) scale(0.86); }
    to   { opacity: 1; transform: translateY(0)    scale(1);    }
  }
  .fab-btn:hover {
    transform: translateY(-2px) scale(1.04);
    box-shadow: 0 10px 32px rgba(26,86,219,0.55), 0 4px 12px rgba(0,0,0,0.24);
    filter: brightness(1.09);
  }
  .fab-btn:active {
    transform: translateY(0) scale(0.97);
    box-shadow: 0 4px 16px rgba(26,86,219,0.35);
  }
  .fab-btn.loading {
    pointer-events: none;
    filter: brightness(0.82);
  }

  /* Icon & spinner inside button */
  .fab-icon {
    display: flex;
    align-items: center;
    flex-shrink: 0;
  }
  .fab-icon svg {
    width: 20px;
    height: 20px;
    fill: none;
    stroke: #ffffff;
    stroke-width: 2.5;
    stroke-linecap: round;
    stroke-linejoin: round;
  }
  .fab-spinner {
    width: 18px;
    height: 18px;
    border: 2.5px solid rgba(255,255,255,0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin 0.65s linear infinite;
    display: none;
    flex-shrink: 0;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  .fab-btn.loading .fab-spinner { display: block; }
  .fab-btn.loading .fab-icon    { display: none;  }

  /* â”€â”€ Toast â”€â”€ */
  .fab-toast {
    position: absolute;
    bottom: 82px;
    right: 20px;
    min-width: 220px;
    max-width: 340px;
    padding: 13px 18px;
    border-radius: 12px;
    font-family: 'Segoe UI', 'Inter', Arial, sans-serif;
    font-size: 13px;
    font-weight: 600;
    line-height: 1.5;
    white-space: pre-line;
    box-shadow: 0 8px 28px rgba(0,0,0,0.24);
    pointer-events: none;
    opacity: 0;
    transform: translateY(10px) scale(0.95);
    transition: opacity 0.25s ease, transform 0.28s cubic-bezier(.22,1,.36,1);
  }
  .fab-toast.visible {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
  .fab-toast.success { background: #0d9e4f; color: #fff; }
  .fab-toast.error   { background: #dc2626; color: #fff; }
  .fab-toast.info    { background: #1a56db; color: #fff; }
`;

/**
 * Create the Shadow DOM host and inject FAB + toast into it.
 * Host is appended to <html> (documentElement) to be immune to
 * body transforms and overflow constraints.
 */
function createFab() {
  if (document.getElementById(FAB_HOST_ID)) return;

  // Host element: fixed at bottom-right corner, zero size, overflow visible
  const host = document.createElement('div');
  host.id = FAB_HOST_ID;
  // Critical host inline styles with !important via setAttribute
  host.setAttribute('style', [
    'position:fixed',
    'bottom:0',
    'right:0',
    'width:0',
    'height:0',
    'overflow:visible',
    'z-index:2147483647',
    'pointer-events:none',
    'display:block',
    'margin:0',
    'padding:0',
    'border:none',
    'background:transparent',
    'transform:none'
  ].join('!important;') + '!important');

  // Attach shadow DOM
  const shadow = host.attachShadow({ mode: 'open' });
  _fabShadow = shadow;

  // Inject styles
  const styleEl = document.createElement('style');
  styleEl.textContent = FAB_SHADOW_CSS;
  shadow.appendChild(styleEl);

  // FAB button
  const btn = document.createElement('button');
  btn.className = 'fab-btn';
  btn.title = 'Add current service order to 1-1-1 Report (no download)';
  btn.innerHTML =
    '<span class="fab-icon">' +
      '<svg viewBox="0 0 24 24">' +
        '<path d="M12 5v14"/>' +
        '<path d="M5 12h14"/>' +
      '</svg>' +
    '</span>' +
    '<span class="fab-spinner"></span>' +
    '<span class="fab-label">Add 1-1-1 Report</span>';
  btn.addEventListener('click', handleFabClick);
  shadow.appendChild(btn);

  // Toast element
  const toast = document.createElement('div');
  toast.className = 'fab-toast';
  shadow.appendChild(toast);

  // Append host to <html>, not <body>, to escape any body-level constraints
  (document.documentElement || document.body).appendChild(host);
}

/** Show a toast inside the shadow DOM */
function showFabToast(message, type, durationMs) {
  type       = type       || 'success';
  durationMs = durationMs || 3200;
  if (!_fabShadow) return;
  const toast = _fabShadow.querySelector('.fab-toast');
  if (!toast) return;
  const icon = type === 'success' ? 'âœ“' : type === 'error' ? 'âœ—' : 'â„¹';
  toast.className = 'fab-toast ' + type;
  toast.innerHTML = '<span style="margin-right:6px">' + icon + '</span>' + message;
  if (toast._timer) clearTimeout(toast._timer);
  void toast.offsetWidth; // reflow
  toast.classList.add('visible');
  toast._timer = setTimeout(function() { toast.classList.remove('visible'); }, durationMs);
}

/** Toggle loading state on the FAB button */
function setFabLoading(on) {
  if (!_fabShadow) return;
  const btn = _fabShadow.querySelector('.fab-btn');
  if (btn) btn.classList.toggle('loading', on);
}

/** Brief color pulse on the FAB after success */
function pulseGreen() {
  if (!_fabShadow) return;
  const btn = _fabShadow.querySelector('.fab-btn');
  if (!btn) return;
  btn.style.background = 'linear-gradient(135deg,#0d9e4f 0%,#34d399 100%)';
  btn.style.boxShadow  = '0 6px 24px rgba(13,158,79,0.5),0 2px 8px rgba(0,0,0,0.18)';
  setTimeout(function() {
    btn.style.background = '';
    btn.style.boxShadow  = '';
  }, 2000);
}

// â”€â”€ Helpers (same as before) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

function mergeColumns111(existing, incoming) {
  const merged = Array.isArray(existing) ? existing.slice() : [];
  for (const col of (Array.isArray(incoming) ? incoming : [])) {
    if (!merged.includes(col)) merged.push(col);
  }
  return merged;
}

function ticketId111(ticket) {
  const so = (ticket && ticket['Service Order No'] ? ticket['Service Order No'] : '').toString().trim();
  if (so) return 'so:' + so.toLowerCase();
  const name = (ticket && ticket['Customer Name'] ? ticket['Customer Name'] : '').toString().trim();
  if (name) return 'name:' + name.toLowerCase();
  return null;
}

const PRODUCT_PFX_111 = {
  RR:'REF',RT:'REF',RF:'REF',RS:'REF',RA:'REF',
  WA:'WM',WT:'WM',WW:'WM',WD:'WM',WF:'WM',
  AR:'RAC',AC:'RAC',AJ:'RAC',AM:'RAC',ACN:'RAC',
  UA:'TV',QA:'TV',HG:'TV',PS:'TV',PN:'TV',UN:'TV',UE:'TV',GU:'TV',
  LH:'DISPLAY',LS:'DISPLAY',
  MC:'MWO',MG:'MWO',MS:'MWO',CE:'MWO',CM:'MWO',
  DW:'DW',DV:'DRYER',VS:'VACUUM',VR:'VACUUM',
  AX:'AIR PURIFIER',HW:'AUDIO',MX:'AUDIO',HT:'AUDIO',
  LC:'MONITOR',LSM:'MONITOR',NV:'OVEN',NQ:'OVEN',NA:'HOB',NZ:'HOB'
};
function getProduct111(model) {
  if (!model) return 'UNKNOWN';
  model = model.toUpperCase().trim();
  const keys = Object.keys(PRODUCT_PFX_111).sort(function(a, b) { return b.length - a.length; });
  for (const k of keys) { if (model.startsWith(k)) return PRODUCT_PFX_111[k]; }
  return 'UNKNOWN';
}

// â”€â”€ Main FAB click handler â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function handleFabClick() {
  setFabLoading(true);
  try {
    // 1. Scrape
    const ticket = await parseViewModeTicket();
    if (!ticket) {
      showFabToast('No service order data found on this page.', 'error');
      return;
    }

    // Add Product field
    const modelVal = (ticket['Model Name'] || ticket['Model'] || '').toString();
    ticket['Product'] = getProduct111(modelVal);

    const incomingColumns = getColumnsForTicket(ticket);
    if (!incomingColumns.includes('Product')) incomingColumns.push('Product');

    // 2. Load session data
    let existingData    = [];
    let existingColumns = [];
    try {
      const stored = await chrome.storage.session.get(['gspn_scrapedData', 'gspn_scrapedColumns']);
      existingData    = Array.isArray(stored.gspn_scrapedData)    ? stored.gspn_scrapedData    : [];
      existingColumns = Array.isArray(stored.gspn_scrapedColumns) ? stored.gspn_scrapedColumns : [];
    } catch (e) { console.warn('[FAB] Session read:', e); }

    // 3. Deduplicate
    const seenKeys = new Set(existingData.map(ticketId111).filter(Boolean));
    const newKey   = ticketId111(ticket);
    if (newKey && seenKeys.has(newKey)) {
      showFabToast('Already in report:\nSO: ' + (ticket['Service Order No'] || ''), 'info', 3500);
      return;
    }

    // 4. Append & save â€” NO download
    const updatedData    = existingData.concat([ticket]);
    const updatedColumns = mergeColumns111(existingColumns, incomingColumns);
    await chrome.storage.session.set({
      gspn_scrapedData:    updatedData,
      gspn_scrapedColumns: updatedColumns,
      gspn_statusMerged:   false
    });

    // 5. Feedback
    const soNo  = ticket['Service Order No'] || 'â€”';
    const cName = ticket['Customer Name']    || '';
    showFabToast(
      'Added to 1-1-1 Report (' + updatedData.length + ' total)\nSO: ' + soNo + (cName ? '\n' + cName : ''),
      'success',
      4000
    );
    pulseGreen();

  } catch (err) {
    console.error('[FAB]', err);
    showFabToast('Error: ' + (err.message || 'Unknown error'), 'error');
  } finally {
    setFabLoading(false);
  }
}

// â”€â”€ Page detection & auto-init â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
function shouldShowFab() {
  const url = window.location.href;
  return (
    url.includes('ServiceOrderDetailLiteCmd')            ||
    url.includes('ServiceOrderListLite')                 ||
    url.includes('so_view_information_by_mangement_lite') ||
    url.includes('manegement_lite')                      ||
    url.includes('call_info_viewing_mode')
  );
}

(function initFab() {
  if (!shouldShowFab()) return;
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', createFab);
  } else {
    createFab();
  }
  // Extra retry for pages with deferred / iframe-based rendering
  setTimeout(function() { if (shouldShowFab()) createFab(); }, 1600);
})();

