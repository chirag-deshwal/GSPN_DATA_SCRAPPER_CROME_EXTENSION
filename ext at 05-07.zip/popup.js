/**
 * GSPN Data Scraper - Popup Script
 * Handles user interaction, triggers content script scraping,
 * and exports scraped data to Excel (.xls) format.
 *
 * Uses chrome.storage.session to persist data across tab switches,
 * since the multi-print page and status page are on DIFFERENT tabs.
 */

let scrapedData = null;
let scrapedColumns = null;
let statusMerged = false;

// Status columns to add during merge
const STATUS_COLUMNS = [
  'Status (GSPN)',
  'Reason (GSPN)',
  'City',
  'App Date',
  'App Time',
  'Wty Status',
  'REDO',
  'Service Type (Status)',
  'B2B'
];

// Product prefix mapping and helper
const PRODUCT_PREFIX = {
    RR: "REF",
    RT: "REF",
    RF: "REF",
    RS: "REF",
    RA: "REF",
    WA: "WM",
    WT: "WM",
    WW: "WM",
    WD: "WM",
    WF: "WM",
    AR: "RAC",
    AC: "RAC",
    AJ: "RAC",
    AM: "RAC",
    ACN: "RAC",
    UA: "TV",
    QA: "TV",
    HG: "TV",
    PS: "TV",
    PN: "TV",
    UN: "TV",
    UE: "TV",
    GU: "TV",
    LH: "DISPLAY",
    LS: "DISPLAY",
    MC: "MWO",
    MG: "MWO",
    MS: "MWO",
    CE: "MWO",
    CM: "MWO",
    DW: "DW",
    DV: "DRYER",
    VS: "VACUUM",
    VR: "VACUUM",
    AX: "AIR PURIFIER",
    HW: "AUDIO",
    MX: "AUDIO",
    HT: "AUDIO",
    LC: "MONITOR",
    LSM: "MONITOR",
    NV: "OVEN",
    NQ: "OVEN",
    NA: "HOB",
    NZ: "HOB"
};

function getSamsungCategory(model) {
    if (!model) return "UNKNOWN";
    model = model.toUpperCase().trim();
    const prefixes = Object.keys(PRODUCT_PREFIX).sort((a, b) => b.length - a.length);
    for (const prefix of prefixes) {
        if (model.startsWith(prefix)) {
            return PRODUCT_PREFIX[prefix];
        }
    }
    return "UNKNOWN";
}

/**
 * Ensure each record has a `Product` field and the columns list contains `Product`.
 * Inserts `Product` right after `Model Name` when possible, otherwise appends.
 */
function ensureProductField(dataArray, columnsArray) {
  if (!Array.isArray(dataArray) || !Array.isArray(columnsArray)) return;

  // Add column if missing
  if (!columnsArray.includes('Product')) {
    const modelIdx = columnsArray.indexOf('Model Name');
    if (modelIdx >= 0) {
      columnsArray.splice(modelIdx + 1, 0, 'Product');
    } else {
      columnsArray.push('Product');
    }
  }

  // Populate product values
  for (const rec of dataArray) {
    const modelVal = (rec['Model Name'] || rec['Model'] || '').toString();
    rec['Product'] = getSamsungCategory(modelVal);
  }
}

// Parse short date and compute aging
function parseShortDateFromAscAssigned(value) {
  if (!value) return null;
  const str = value.toString();
  // Try common date patterns: dd/mm/yyyy or yyyy-mm-dd or mm/dd/yyyy
  const dateMatch = str.match(/(\d{1,4}[\/\-]\d{1,2}[\/\-]\d{1,4})/);
  if (!dateMatch) return null;
  const d = dateMatch[1];
  if (d.indexOf('-') >= 0) {
    // Possible yyyy-mm-dd or dd-mm-yyyy; prefer yyyy-mm-dd when year has 4 digits at start
    const parts = d.split('-');
    if (parts[0].length === 4) {
      // yyyy-mm-dd
      const y = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      const day = parseInt(parts[2], 10);
      return new Date(y, m - 1, day);
    } else {
      // assume dd-mm-yyyy
      const day = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      const y = parseInt(parts[2], 10);
      return new Date(y, m - 1, day);
    }
  }

  if (d.indexOf('/') >= 0) {
    const parts = d.split('/');
    // assume dd/mm/yyyy (common in examples)
    if (parts[2] && parts[2].length === 4) {
      const day = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10);
      const y = parseInt(parts[2], 10);
      return new Date(y, m - 1, day);
    }
    // fallback: try mm/dd/yyyy
    const m = parseInt(parts[0], 10);
    const day = parseInt(parts[1], 10);
    const y = parseInt(parts[2], 10);
    return new Date(y, m - 1, day);
  }

  return null;
}

function formatDateDDMMYYYY(dateObj) {
  if (!(dateObj instanceof Date) || isNaN(dateObj.getTime())) return '';
  const dd = String(dateObj.getDate()).padStart(2, '0');
  const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
  const yyyy = dateObj.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

function ensureAscAssignedShortAndAging(dataArray, columnsArray) {
  if (!Array.isArray(dataArray) || !Array.isArray(columnsArray)) return;

  // Ensure Short ASC Assigned Date column exists
  if (!columnsArray.includes('Short ASC Assigned Date')) {
    const ascIdx = columnsArray.indexOf('ASC Assigned');
    if (ascIdx >= 0) {
      columnsArray.splice(ascIdx + 1, 0, 'Short ASC Assigned Date');
    } else {
      columnsArray.push('Short ASC Assigned Date');
    }
  }

  // Ensure Aging column exists after Short ASC Assigned Date
  if (!columnsArray.includes('Aging')) {
    const shortIdx = columnsArray.indexOf('Short ASC Assigned Date');
    if (shortIdx >= 0) {
      columnsArray.splice(shortIdx + 1, 0, 'Aging');
    } else {
      columnsArray.push('Aging');
    }
  }

  const today = new Date();
  // normalize to midnight
  const todayMid = new Date(today.getFullYear(), today.getMonth(), today.getDate());

  for (const rec of dataArray) {
    const raw = rec['ASC Assigned'] || rec['ASC_Assigned'] || rec['ASCAssigned'] || '';
    const parsed = parseShortDateFromAscAssigned(raw);
    if (parsed && !isNaN(parsed.getTime())) {
      rec['Short ASC Assigned Date'] = formatDateDDMMYYYY(parsed);
      const parsedMid = new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
      const diffMs = todayMid - parsedMid;
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      rec['Aging'] = diffDays;
    } else {
      rec['Short ASC Assigned Date'] = '';
      rec['Aging'] = '';
    }
  }
}

// DOM Elements
const btnScrape = document.getElementById('btnScrape');
const btnViewModeScrape = document.getElementById('btnViewModeScrape');
const btnAppendScrape = document.getElementById('btnAppendScrape');
const btnExport = document.getElementById('btnExport');
const btnCopy = document.getElementById('btnCopy');
const statusBar = document.getElementById('statusBar');
const statusText = document.getElementById('statusText');
const statsSection = document.getElementById('statsSection');
const ticketCount = document.getElementById('ticketCount');
const fieldCount = document.getElementById('fieldCount');
const previewSection = document.getElementById('previewSection');
const previewHead = document.getElementById('previewHead');
const previewBody = document.getElementById('previewBody');
const previewInfo = document.getElementById('previewInfo');
const errorSection = document.getElementById('errorSection');
const errorText = document.getElementById('errorText');

// Status merge elements
const statusSection = document.getElementById('statusSection');
const btnAddStatus = document.getElementById('btnAddStatus');
const statusMergeHint = document.getElementById('statusMergeHint');
const mergeResult = document.getElementById('mergeResult');
const mergeResultIcon = document.getElementById('mergeResultIcon');
const mergeResultText = document.getElementById('mergeResultText');

// Auto-export checkbox for 1-1-1 scrape
const chkAutoExport111 = document.getElementById('chkAutoExport111');

// Closer Helper — toggle & settings
const btnCloserSettings = document.getElementById('btnCloserSettings');
const chkCloserHelper = document.getElementById('chkCloserHelper');
const chkCloserStatus = document.getElementById('chkCloserStatus');
const chkOpenInNewTab = document.getElementById('chkOpenInNewTab');
const closerCard = document.querySelector('.closer-helper-card');

// Profile button
const btnProfiles = document.getElementById('btnProfiles');
const btnToggleLogs = document.getElementById('btnToggleLogs');
const loginGate = document.getElementById('loginGate');
const popupMainContent = document.getElementById('popupMainContent');
const btnOpenProfileLogin = document.getElementById('btnOpenProfileLogin');
const btnClearLogs = document.getElementById('btnClearLogs');
const logsPanel = document.getElementById('logsPanel');
const logsList = document.getElementById('logsList');
const tabButtons = document.querySelectorAll('.tab-item');
const tabPanes = document.querySelectorAll('.tab-pane');

function formatLogValue(value) {
  if (typeof value === 'string') return value;
  if (value instanceof Error) return value.message;
  try {
    return JSON.stringify(value);
  } catch (error) {
    return String(value);
  }
}

function setupPopupLogBridge() {
  ['log', 'info', 'warn', 'error', 'debug'].forEach((method) => {
    const original = console[method];
    console[method] = (...args) => {
      const message = args.map(formatLogValue).join(' ');
      if (message) {
        chrome.runtime.sendMessage({
          action: 'extensionLog',
          entry: {
            source: 'popup',
            level: method,
            message,
            timestamp: new Date().toISOString()
          }
        }).catch(() => {});
      }
      if (original) {
        original.apply(console, args);
      }
    };
  });
}

setupPopupLogBridge();

async function loadLogs() {
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getExtensionLogs' });
    const logs = Array.isArray(response?.logs) ? response.logs : [];
    renderLogs(logs);
  } catch (error) {
    console.warn('Failed to load logs:', error);
    renderLogs([]);
  }
}

function renderLogs(logs) {
  if (!logsList) return;
  if (!logs || logs.length === 0) {
    logsList.innerHTML = '<div class="log-empty">No extension logs captured yet.</div>';
    return;
  }

  const html = logs.slice().reverse().map((entry) => {
    const levelClass = `log-${(entry.level || 'log').toLowerCase()}`;
    const ts = entry.timestamp ? new Date(entry.timestamp).toLocaleString() : 'Unknown time';
    return `
      <div class="log-entry ${levelClass}">
        <div class="log-meta">
          <span>${escapeHtml(entry.source || 'unknown')}</span>
          <span>${escapeHtml(ts)}</span>
        </div>
        <div class="log-message">${escapeHtml(entry.message || '')}</div>
      </div>`;
  }).join('');

  logsList.innerHTML = html;
}

async function clearLogs() {
  try {
    await chrome.runtime.sendMessage({ action: 'clearExtensionLogs' });
    renderLogs([]);
  } catch (error) {
    console.warn('Failed to clear logs:', error);
  }
}

if (btnToggleLogs) {
  btnToggleLogs.addEventListener('click', () => {
    if (!logsPanel) return;
    const willShow = logsPanel.classList.contains('hidden');
    logsPanel.classList.toggle('hidden', !willShow);
    if (willShow) {
      loadLogs();
    }
  });
}

if (btnClearLogs) {
  btnClearLogs.addEventListener('click', () => {
    clearLogs();
  });
}

function setupTabNavigation() {
  if (!tabButtons.length || !tabPanes.length) return;

  tabButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const targetId = button.dataset.target;
      if (!targetId) return;

      tabButtons.forEach((btn) => btn.classList.toggle('active', btn === button));
      tabPanes.forEach((pane) => {
        pane.classList.toggle('hidden', pane.id !== targetId);
      });

      if (targetId === 'pane-tracking') {
        if (logsPanel) {
          logsPanel.classList.remove('hidden');
        }
        loadLogs();
      }
    });
  });
}

loadLogs();
setupTabNavigation();

// =====================================================
// Profile Manager Integration
// =====================================================

/**
 * Load profile settings on popup open
 */
async function loadProfileSettings() {
  try {
    const currentProfile = await profileManager.getCurrentProfile();
    if (currentProfile) {
      // Apply settings from profile
      if (chkCloserHelper) {
        chkCloserHelper.checked = currentProfile.settings.closerHelperEnabled;
        updateCloserUI(currentProfile.settings.closerHelperEnabled);
      }
    } else {
      // No active profile, load from chrome.storage.local (legacy support)
      chrome.storage.local.get(['closerHelperEnabled', 'openRequestsInNewTab'], (data) => {
        const enabled = !!data.closerHelperEnabled;
        if (chkCloserHelper) chkCloserHelper.checked = enabled;
        if (chkOpenInNewTab) chkOpenInNewTab.checked = !!data.openRequestsInNewTab;
        updateCloserUI(enabled);
      });
    }
  } catch (error) {
    console.warn('Failed to load profile settings:', error);
  }
}

// Load profile settings on popup open
updateLoginGateVisibility();
loadProfileSettings();

// Toggle handler
if (chkCloserHelper) {
  chkCloserHelper.addEventListener('change', () => {
    const enabled = chkCloserHelper.checked;
    chrome.storage.local.set({ closerHelperEnabled: enabled });
    updateCloserUI(enabled);
    
    // Also update current profile if one is active
    chrome.storage.local.get('currentProfile', (data) => {
      if (data.currentProfile) {
        profileManager.updateProfile(data.currentProfile.id, {
          settings: { closerHelperEnabled: enabled }
        }).catch(err => console.warn('Failed to update profile:', err));
      }
    });
  });
}

if (chkOpenInNewTab) {
  chkOpenInNewTab.addEventListener('change', () => {
    chrome.storage.local.set({ openRequestsInNewTab: chkOpenInNewTab.checked });
  });
}

function updateCloserUI(enabled) {
  if (chkCloserStatus) {
    chkCloserStatus.textContent = enabled
      ? 'Enabled — floating panel active on GSPN page'
      : 'Disabled — toggle to enable on GSPN page';
    chkCloserStatus.classList.toggle('active', enabled);
  }
  if (closerCard) {
    closerCard.classList.toggle('enabled', enabled);
  }
}

// Open settings page
if (btnCloserSettings) {
  btnCloserSettings.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('closer_helper_settings.html') });
  });
}

function updateLoginGateVisibility() {
  chrome.storage.local.get(['savedLoginUserId', 'savedLoginPassword', 'lastLoginStatus'], (data) => {
    const isLoggedIn = !!data.savedLoginUserId && !!data.savedLoginPassword && data.lastLoginStatus === 'success';
    if (loginGate) {
      loginGate.classList.toggle('hidden', isLoggedIn);
    }
    if (popupMainContent) {
      popupMainContent.classList.toggle('hidden', !isLoggedIn);
    }

    if (isLoggedIn) {
      loadProfileSettings();
      restoreSession();
    }
  });
}

if (btnOpenProfileLogin) {
  btnOpenProfileLogin.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('profiles.html') });
  });
}

// Open profiles manager
if (btnProfiles) {
  btnProfiles.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('profiles.html') });
  });
}

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && (changes.savedLoginUserId || changes.savedLoginPassword || changes.lastLoginStatus)) {
    updateLoginGateVisibility();
  }
});

// Listen for profile application messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'profileApplied') {
    // Reload settings from the applied profile
    loadProfileSettings();
  }
});

// =====================================================
// SESSION STORAGE — persist data across tab switches
// =====================================================

/**
 * Save current state to chrome.storage.session.
 * Called after scraping and after merging status.
 */
async function saveSession() {
  try {
    await chrome.storage.session.set({
      gspn_scrapedData: scrapedData,
      gspn_scrapedColumns: scrapedColumns,
      gspn_statusMerged: statusMerged
    });
  } catch (e) {
    console.warn('Failed to save session:', e);
  }
}

/**
 * Restore state from chrome.storage.session on popup open.
 * This is critical when user switches from multi-print tab to status tab.
 */
async function restoreSession() {
  try {
    const stored = await chrome.storage.session.get([
      'gspn_scrapedData',
      'gspn_scrapedColumns',
      'gspn_statusMerged'
    ]);

    if (stored.gspn_scrapedData && stored.gspn_scrapedData.length > 0) {
      scrapedData = stored.gspn_scrapedData;
      scrapedColumns = stored.gspn_scrapedColumns;
      // Ensure Product column/value exists for restored data
      ensureProductField(scrapedData, scrapedColumns);
      // Ensure Short ASC Assigned Date and Aging are present
      ensureAscAssignedShortAndAging(scrapedData, scrapedColumns);
      statusMerged = stored.gspn_statusMerged || false;

      // Restore UI state
      ticketCount.textContent = scrapedData.length;
      fieldCount.textContent = scrapedColumns.length;
      statsSection.classList.remove('hidden');
      updateActionButtonsState();
      statusSection.classList.remove('hidden');

      // Build preview
      buildPreview(scrapedData, scrapedColumns);
      previewSection.classList.remove('hidden');

      if (statusMerged) {
        setStatus('success', `${scrapedData.length} ticket(s) with status data — ready to export`);
        statusMergeHint.textContent = '✓ Status already merged — you can export or re-merge';
        // Show a green merge result
        mergeResult.classList.remove('hidden', 'merge-error', 'merge-partial');
        mergeResult.classList.add('merge-success');
        mergeResultIcon.textContent = '✓';
        mergeResultText.textContent = 'Status data merged — switch tabs freely';
      } else {
        setStatus('success', `${scrapedData.length} ticket(s) loaded — navigate to status page to add status`);
      }
    }
  } catch (e) {
    console.warn('Failed to restore session:', e);
  }
}

/**
 * Clear persisted session data
 */
async function clearSession() {
  try {
    await chrome.storage.session.remove([
      'gspn_scrapedData',
      'gspn_scrapedColumns',
      'gspn_statusMerged'
    ]);
  } catch (e) {
    console.warn('Failed to clear session:', e);
  }
}

updateActionButtonsState();

// Restore session on popup open
restoreSession();

// ---- Action State Helpers ----
function updateActionButtonsState() {
  const hasData = !!scrapedData && scrapedData.length > 0;
  if (btnExport) btnExport.disabled = !hasData;
  if (btnCopy) btnCopy.disabled = !hasData;
  if (btnAppendScrape) btnAppendScrape.disabled = !hasData;
}

function getTicketIdentity(ticket) {
  const serviceOrderNo = (ticket?.['Service Order No'] || '').toString().trim();
  const customerName = (ticket?.['Customer Name'] || '').toString().trim();

  if (serviceOrderNo) {
    return `so:${serviceOrderNo.toLowerCase()}`;
  }

  if (customerName) {
    return `name:${customerName.toLowerCase()}`;
  }

  return null;
}

function mergeScrapedData(existingData, incomingData) {
  const merged = Array.isArray(existingData) ? [...existingData] : [];
  const seen = new Set();

  for (const ticket of merged) {
    const identity = getTicketIdentity(ticket);
    if (identity) {
      seen.add(identity);
    }
  }

  for (const ticket of Array.isArray(incomingData) ? incomingData : []) {
    const identity = getTicketIdentity(ticket);
    if (!identity || seen.has(identity)) continue;
    seen.add(identity);
    merged.push(ticket);
  }

  return merged;
}

function mergeScrapedColumns(existingColumns, incomingColumns) {
  const merged = Array.isArray(existingColumns) ? [...existingColumns] : [];

  for (const column of Array.isArray(incomingColumns) ? incomingColumns : []) {
    if (!merged.includes(column)) {
      merged.push(column);
    }
  }

  return merged;
}

// ---- Status Helpers ----
function setStatus(type, message) {
  statusBar.className = `status-bar status-${type}`;
  statusText.textContent = message;
}

function showError(msg) {
  errorSection.classList.remove('hidden');
  errorText.textContent = msg;
}

function hideError() {
  errorSection.classList.add('hidden');
}

// ---- Scrape Handler ----
btnScrape.addEventListener('click', async () => {
  hideError();
  statsSection.classList.add('hidden');
  previewSection.classList.add('hidden');
  statusSection.classList.add('hidden');
  mergeResult.classList.add('hidden');
  btnScrape.classList.add('loading');
  setStatus('loading', 'Scraping data...');

  try {
    // Get the active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      throw new Error('No active tab found.');
    }

    // Check URL
    if (!tab.url || !tab.url.includes('biz2.samsungcsportal.com')) {
      throw new Error('Please navigate to the GSPN portal (biz2.samsungcsportal.com) first.');
    }

    // Inject content script if not already loaded (in case page was loaded before extension)
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
    } catch (e) {
      // Script may already be injected, continue
    }

    // Send message to content script
    const response = await chrome.tabs.sendMessage(tab.id, { action: 'scrapeData' });

    if (!response) {
      throw new Error('No response from page. Please reload the GSPN page and try again.');
    }

    if (!response.success) {
      throw new Error(response.error || 'Failed to scrape data.');
    }

    if (response.count === 0) {
      throw new Error('No service tickets found on this page. Make sure you are on the multi-print page.');
    }

    // Store data
    scrapedData = response.data;
    scrapedColumns = response.columns;
    statusMerged = false;
    // Populate Product column/value based on Model Name
    ensureProductField(scrapedData, scrapedColumns);
    // Populate Short ASC Assigned Date and Aging
    ensureAscAssignedShortAndAging(scrapedData, scrapedColumns);

    // Save to session storage (persists across tab switches!)
    await saveSession();

    // Update UI
    setStatus('success', `Successfully scraped ${response.count} ticket(s)`);
    ticketCount.textContent = response.count;
    fieldCount.textContent = scrapedColumns.length;
    statsSection.classList.remove('hidden');
    updateActionButtonsState();

    // Show the status merge section
    statusSection.classList.remove('hidden');
    statusMergeHint.textContent = 'Navigate to Service Order Management Light page, then click below';

    // Build preview (show first 5 tickets, limited columns)
    buildPreview(scrapedData, scrapedColumns);
    previewSection.classList.remove('hidden');

  } catch (error) {
    setStatus('error', 'Scrape failed');
    showError(error.message || 'An unknown error occurred.');
  } finally {
    btnScrape.classList.remove('loading');
  }
});

  if (btnViewModeScrape) {
  btnViewModeScrape.addEventListener('click', async () => {
    hideError();
    statsSection.classList.add('hidden');
    previewSection.classList.add('hidden');
    statusSection.classList.add('hidden');
    mergeResult.classList.add('hidden');
    btnViewModeScrape.classList.add('loading');
    setStatus('loading', 'Scraping view-mode labels...');

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab) {
        throw new Error('No active tab found.');
      }

      // Allow both biz2.samsungcsportal.com and local saved HTML files for testing
      const isGspnUrl = tab.url && tab.url.includes('biz2.samsungcsportal.com');
      const isLocalManagementLite = tab.url && (
        tab.url.includes('so_view_information_by_mangement_lite')
        || tab.url.includes('call_info_viewing_mode')
        || tab.url.includes('manegement_lite')
      );

      if (!tab.url || (!isGspnUrl && !isLocalManagementLite)) {
        throw new Error('Please navigate to the GSPN portal or open the Service Order detail / Management Lite page first.');
      }

      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['viewModeContent.js']
        });
      } catch (e) {
        console.warn('Failed to inject viewModeContent.js:', e);
      }

      const response = await chrome.tabs.sendMessage(tab.id, { action: 'scrapeViewMode' });

      if (!response) {
        throw new Error('No response from page. Please reload the page and try again.');
      }

      if (!response.success) {
        throw new Error(response.error || 'Failed to scrape view-mode data.');
      }

      if (response.count === 0) {
        throw new Error('No view-mode ticket data found on this page.');
      }

      scrapedData = response.data;
      scrapedColumns = response.columns;
      statusMerged = false;
      // Populate Product column/value based on Model Name
      ensureProductField(scrapedData, scrapedColumns);
      // Populate Short ASC Assigned Date and Aging
      ensureAscAssignedShortAndAging(scrapedData, scrapedColumns);

      await saveSession();

      setStatus('success', `Successfully scraped ${response.count} view-mode ticket(s)`);
      ticketCount.textContent = response.count;
      fieldCount.textContent = scrapedColumns.length;
      statsSection.classList.remove('hidden');
      updateActionButtonsState();

      statusSection.classList.remove('hidden');
      statusMergeHint.textContent = 'Navigate to Service Order Management Light page, then click below';

      buildPreview(scrapedData, scrapedColumns);
      previewSection.classList.remove('hidden');

      // Auto-export to Excel if the checkbox is enabled
      const autoExport = chkAutoExport111 && chkAutoExport111.checked;
      if (autoExport) {
        autoExportToExcel();
      }

    } catch (error) {
      setStatus('error', 'View-mode scrape failed');
      showError(error.message || 'An unknown error occurred.');
    } finally {
      btnViewModeScrape.classList.remove('loading');
    }
  });
}

// ---- Append Scrape Handler ----
if (btnAppendScrape) {
  btnAppendScrape.addEventListener('click', async () => {
    hideError();
    btnAppendScrape.classList.add('loading');
    setStatus('loading', 'Appending new data...');

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (!tab) {
        throw new Error('No active tab found.');
      }

      if (!tab.url || !tab.url.includes('biz2.samsungcsportal.com')) {
        throw new Error('Please navigate to the GSPN portal (biz2.samsungcsportal.com) first.');
      }

      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        });
      } catch (e) {
        // Script may already be injected, continue
      }

      const response = await chrome.tabs.sendMessage(tab.id, { action: 'scrapeData' });

      if (!response) {
        throw new Error('No response from page. Please reload the GSPN page and try again.');
      }

      if (!response.success) {
        throw new Error(response.error || 'Failed to scrape data.');
      }

      if (response.count === 0) {
        throw new Error('No service tickets found on this page. Make sure you are on the multi-print page.');
      }

      const existingData = Array.isArray(scrapedData) ? scrapedData : [];
      const mergedData = mergeScrapedData(existingData, response.data);
      const mergedColumns = mergeScrapedColumns(scrapedColumns, response.columns);

      scrapedData = mergedData;
      scrapedColumns = mergedColumns;
      statusMerged = statusMerged;
      // Ensure Product column/value after merging
      ensureProductField(scrapedData, scrapedColumns);
      // Ensure Short ASC Assigned Date and Aging after merging
      ensureAscAssignedShortAndAging(scrapedData, scrapedColumns);

      await saveSession();

      const addedCount = mergedData.length - existingData.length;
      setStatus('success', `Added ${addedCount} new ticket(s). Total ${mergedData.length} ticket(s)`);
      ticketCount.textContent = mergedData.length;
      fieldCount.textContent = scrapedColumns.length;
      statsSection.classList.remove('hidden');
      updateActionButtonsState();
      statusSection.classList.remove('hidden');
      statusMergeHint.textContent = 'Added more records — export or merge status again';
      buildPreview(scrapedData, scrapedColumns);
      previewSection.classList.remove('hidden');
    } catch (error) {
      setStatus('error', 'Append failed');
      showError(error.message || 'An unknown error occurred.');
    } finally {
      btnAppendScrape.classList.remove('loading');
    }
  });
}

// ---- Add Status Handler ----
btnAddStatus.addEventListener('click', async () => {
  hideError();
  mergeResult.classList.add('hidden');
  btnAddStatus.classList.add('loading');
  setStatus('loading', 'Fetching status data...');

  // Make sure we have scraped data (restore from session if needed)
  if (!scrapedData || scrapedData.length === 0) {
    try {
      const stored = await chrome.storage.session.get(['gspn_scrapedData', 'gspn_scrapedColumns']);
      if (stored.gspn_scrapedData && stored.gspn_scrapedData.length > 0) {
        scrapedData = stored.gspn_scrapedData;
        scrapedColumns = stored.gspn_scrapedColumns;
      }
    } catch (e) { /* ignore */ }
  }

  if (!scrapedData || scrapedData.length === 0) {
    setStatus('error', 'No scraped data');
    showMergeError('Please scrape ticket data first (Step 1), then come back here.');
    btnAddStatus.classList.remove('loading');
    return;
  }

  try {
    // Get the active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      throw new Error('No active tab found.');
    }

    // Inject the statusContent.js script into the current tab
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['statusContent.js']
      });
    } catch (e) {
      // Script may already be injected
    }

    // Request status data from the status page
    const response = await chrome.tabs.sendMessage(tab.id, { action: 'scrapeStatus' });

    if (!response) {
      throw new Error('No response from status page. Please make sure you are on the Service Order Management Light page.');
    }

    if (!response.success) {
      throw new Error(response.error || 'Failed to scrape status data.');
    }

    if (response.count === 0) {
      throw new Error('No status records found on this page. Please ensure Service Order data is loaded.');
    }

    // Perform VLOOKUP merge
    const mergeStats = mergeStatusData(response.data);

    // Update columns list (add status columns that aren't already present)
    for (const col of STATUS_COLUMNS) {
      if (!scrapedColumns.includes(col)) {
        scrapedColumns.push(col);
      }
    }

    // Update UI
    statusMerged = true;
    fieldCount.textContent = scrapedColumns.length;
    updateActionButtonsState();

    // Save merged data back to session storage!
    await saveSession();

    // Show merge result
    showMergeResult(mergeStats);

    // Refresh preview with new columns
    buildPreview(scrapedData, scrapedColumns);

    setStatus('success', `Status merged: ${mergeStats.matched} of ${scrapedData.length} matched`);
    statusMergeHint.textContent = `✓ ${mergeStats.matched} matched, ${mergeStats.unmatched} unmatched — from ${response.count} status records`;

  } catch (error) {
    setStatus('error', 'Status merge failed');
    showMergeError(error.message);
  } finally {
    btnAddStatus.classList.remove('loading');
  }
});

/**
 * VLOOKUP merge: match scraped tickets with status records by Service Order No
 */
function mergeStatusData(statusRecords) {
  // Build a lookup map from Service Order No -> status record
  const statusMap = new Map();
  for (const record of statusRecords) {
    const soNo = record['Service Order No'];
    if (soNo) {
      statusMap.set(soNo.trim(), record);
    }
  }

  let matched = 0;
  let unmatched = 0;

  // Iterate through scraped data and merge matching status
  for (const ticket of scrapedData) {
    const ticketSO = (ticket['Service Order No'] || '').trim();
    if (!ticketSO) {
      unmatched++;
      continue;
    }

    const statusRecord = statusMap.get(ticketSO);
    if (statusRecord) {
      // Merge status fields into the ticket (don't overwrite existing)
      for (const col of STATUS_COLUMNS) {
        if (statusRecord[col] && statusRecord[col] !== '') {
          // Only add if the ticket doesn't already have this field, or the field is empty
          if (!ticket[col] || ticket[col] === '' || ticket[col] === '-') {
            ticket[col] = statusRecord[col];
          }
        }
      }
      matched++;
    } else {
      unmatched++;
    }
  }

  return { matched, unmatched, totalStatus: statusRecords.length };
}

/**
 * Show merge result badge
 */
function showMergeResult(stats) {
  mergeResult.classList.remove('hidden', 'merge-success', 'merge-partial', 'merge-error');

  if (stats.matched === scrapedData.length) {
    mergeResult.classList.add('merge-success');
    mergeResultIcon.textContent = '✓';
    mergeResultText.textContent = `All ${stats.matched} tickets matched with status data`;
  } else if (stats.matched > 0) {
    mergeResult.classList.add('merge-partial');
    mergeResultIcon.textContent = '⚡';
    mergeResultText.textContent = `${stats.matched} matched, ${stats.unmatched} unmatched`;
  } else {
    mergeResult.classList.add('merge-error');
    mergeResultIcon.textContent = '✗';
    mergeResultText.textContent = 'No matching tickets found in status data';
  }
}

/**
 * Show merge error
 */
function showMergeError(msg) {
  mergeResult.classList.remove('hidden', 'merge-success', 'merge-partial', 'merge-error');
  mergeResult.classList.add('merge-error');
  mergeResultIcon.textContent = '✗';
  mergeResultText.textContent = msg;
}

// ---- Preview Table ----
function buildPreview(data, columns) {
  // Show max 5 rows, and limited columns for preview
  // Show different preview columns based on whether status has been merged
  const baseCols = ['Service Order No', 'Customer Name', 'Model Name', 'Telephone (Mobile)', 'Engineer'];
  const statusPreviewCols = ['Service Order No', 'Customer Name', 'Status (GSPN)', 'Reason (GSPN)', 'City'];
  const previewCols = statusMerged ? statusPreviewCols : baseCols;
  const maxRows = 5;

  // Head
  let headHTML = '<tr>';
  headHTML += '<th>#</th>';
  for (const col of previewCols) {
    headHTML += `<th>${col}</th>`;
  }
  headHTML += '</tr>';
  previewHead.innerHTML = headHTML;

  // Body
  let bodyHTML = '';
  const rowCount = Math.min(data.length, maxRows);
  for (let i = 0; i < rowCount; i++) {
    bodyHTML += '<tr>';
    bodyHTML += `<td>${i + 1}</td>`;
    for (const col of previewCols) {
      bodyHTML += `<td title="${escapeHtml(data[i][col] || '')}">${escapeHtml(data[i][col] || '-')}</td>`;
    }
    bodyHTML += '</tr>';
  }
  previewBody.innerHTML = bodyHTML;
  previewInfo.textContent = data.length > maxRows
    ? `Showing ${maxRows} of ${data.length} records`
    : `${data.length} record(s)`;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ---- Auto-export Checkbox State ----
// Persist the auto-export checkbox state
if (chkAutoExport111) {
  // Restore saved state
  chrome.storage.local.get(['autoExport111Enabled'], (data) => {
    chkAutoExport111.checked = !!data.autoExport111Enabled;
  });
  chkAutoExport111.addEventListener('change', () => {
    chrome.storage.local.set({ autoExport111Enabled: chkAutoExport111.checked });
  });
}

/**
 * Auto-export current scraped data to Excel (used when auto-export checkbox is on).
 * Triggers a download silently without prompting saveAs dialog.
 */
function autoExportToExcel() {
  if (!scrapedData || scrapedData.length === 0) return;
  try {
    const filename = `GSPN_1-1-1_${getTimestamp()}.xls`;
    const excelContent = generateExcelHTML(scrapedData, scrapedColumns);
    const blob = new Blob([excelContent], {
      type: 'application/vnd.ms-excel;charset=utf-8'
    });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: url,
      filename: filename,
      saveAs: false // Auto-save without prompt
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.warn('Auto-export failed:', chrome.runtime.lastError.message);
      } else {
        setStatus('success', `✓ Auto-exported ${scrapedData.length} ticket(s) to Excel`);
      }
      URL.revokeObjectURL(url);
    });
  } catch (error) {
    console.warn('Auto-export error:', error);
  }
}

// ---- Export to Excel ----
btnExport.addEventListener('click', () => {
  if (!scrapedData || scrapedData.length === 0) return;

  try {
    setStatus('loading', 'Generating Excel file...');

    const filename = `GSPN_Data_${getTimestamp()}.xls`;
    const excelContent = generateExcelHTML(scrapedData, scrapedColumns);

    // Create a Blob and download
    const blob = new Blob([excelContent], {
      type: 'application/vnd.ms-excel;charset=utf-8'
    });
    const url = URL.createObjectURL(blob);

    chrome.downloads.download({
      url: url,
      filename: filename,
      saveAs: true
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        setStatus('error', 'Download failed');
        showError(chrome.runtime.lastError.message);
      } else {
        setStatus('success', `Exported ${scrapedData.length} tickets to Excel`);
      }
    });

  } catch (error) {
    setStatus('error', 'Export failed');
    showError(error.message);
  }
});

// ---- Copy to Clipboard ----
if (btnCopy) {
  btnCopy.addEventListener('click', async () => {
    if (!scrapedData || scrapedData.length === 0) return;

    try {
      const originalText = btnCopy.innerHTML;
      btnCopy.classList.add('loading');
      setStatus('loading', 'Copying to clipboard...');

      const excelContent = generateExcelHTML(scrapedData, scrapedColumns);
      
      const clipboardItemInput = new ClipboardItem({
        'text/html': new Blob([excelContent], { type: 'text/html' })
      });
      
      await navigator.clipboard.write([clipboardItemInput]);
      
      setStatus('success', `Copied ${scrapedData.length} tickets to clipboard`);
      
      // Temporary success state for the button
      btnCopy.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';
      setTimeout(() => {
        btnCopy.innerHTML = originalText;
      }, 2000);
      
    } catch (error) {
      setStatus('error', 'Copy failed');
      showError('Could not copy to clipboard. Please use export instead. ' + error.message);
    } finally {
      btnCopy.classList.remove('loading');
    }
  });
}

/**
 * Generate an HTML table that Excel can open natively as a .xls file.
 * This approach supports formatting, column widths, and UTF-8 text.
 */
function generateExcelHTML(data, columns) {
  let html = `
<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <!--[if gte mso 9]>
  <xml>
    <x:ExcelWorkbook>
      <x:ExcelWorksheets>
        <x:ExcelWorksheet>
          <x:Name>GSPN Data</x:Name>
          <x:WorksheetOptions>
            <x:DisplayGridlines/>
          </x:WorksheetOptions>
        </x:ExcelWorksheet>
      </x:ExcelWorksheets>
    </x:ExcelWorkbook>
  </xml>
  <![endif]-->
  <style>
    table { border-collapse: collapse; }
    th {
      background-color: #1a56db;
      color: #ffffff;
      font-weight: bold;
      font-size: 11pt;
      padding: 8px 12px;
      border: 1px solid #999999;
      text-align: center;
      white-space: nowrap;
    }
    td {
      font-size: 10pt;
      padding: 6px 10px;
      border: 1px solid #cccccc;
      vertical-align: top;
    }
    tr:nth-child(even) td {
      background-color: #f0f4ff;
    }
    .num { mso-number-format:\\@; }
  </style>
</head>
<body>
  <table>
    <thead>
      <tr>
        <th>S.No</th>`;

  // Header row
  for (const col of columns) {
    html += `\n        <th>${escapeHtml(col)}</th>`;
  }

  html += `
      </tr>
    </thead>
    <tbody>`;

  // Data rows
  for (let i = 0; i < data.length; i++) {
    html += `\n      <tr>`;
    html += `\n        <td style="text-align:center;">${i + 1}</td>`;
    for (const col of columns) {
      const value = data[i][col] || '';
      // Force text format for phone numbers and IDs to prevent Excel
      // from converting them to scientific notation
      const isNumericField = col.includes('Telephone') || col.includes('Customer No') || col.includes('Order No');
      if (isNumericField && value) {
        html += `\n        <td class="num">${escapeHtml(value)}</td>`;
      } else {
        html += `\n        <td>${escapeHtml(value)}</td>`;
      }
    }
    html += `\n      </tr>`;
  }

  html += `
    </tbody>
  </table>
</body>
</html>`;

  return html;
}

function getTimestamp() {
  const now = new Date();
  const dd = String(now.getDate()).padStart(2, '0');
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const yyyy = now.getFullYear();
  const hh = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  return `${dd}-${mm}-${yyyy}_${hh}${min}`;
}
